from flask import Flask, render_template,request,redirect, url_for
from flask_graphql import GraphQLView
import graphene
import mysql.connector

mydb = mysql.connector.connect(
    host = "localhost",
    user = "root",
    port = 3306,
    password= "",
    database ="DB proyecto final",
)

myCursor = mydb.cursor()

app = Flask(__name__)

app.static_folder = 'Static'

"""-----------Graph QL------------"""

#tipos de datos GraphQL
class Usuario(graphene.ObjectType):
    id = graphene.ID()
    nombre = graphene.String()
    email = graphene.String()

#consulta 
class Query(graphene.ObjectType):
    usuario = graphene.Field(Usuario, id=graphene.Int())

    def resolve_usuario(self, info, id):
        query = "SELECT id, nombre, email FROM usuarios WHERE id = %s"
        with mydb.cursor() as cursor:
            cursor.execute(query, (id,))
            user_data = cursor.fetchone()
            if user_data:
                return Usuario(id=user_data[0], nombre=user_data[1], email=user_data[2])
            else:
                return None

    all_users = graphene.List(Usuario)
    
    def resolve_all_users(self, info):
        query = "SELECT id, nombre, email FROM usuarios"
        with mydb.cursor() as cursor:
            cursor.execute(query)
            users_data = cursor.fetchall()
            return [Usuario(id=user[0], nombre=user[1], email=user[2]) for user in users_data]

schema = graphene.Schema(query=Query)

#agregamos la ruta (ej: localhost:5000/graphql)
app.add_url_rule('/graphql', view_func=GraphQLView.as_view('graphql', schema=schema, graphiql=True))

"""-----------Graph QL Finished------------"""

@app.route('/')
def index():
    return redirect(url_for('landing'))
@app.route('/landing')
def landing():
    user_id = request.args.get('user_id', '')
    user_data = fetch_user_data(user_id)
    return render_template('landing.html', user_data=user_data)

def fetch_user_data(user_id):
    myCursor = mydb.cursor()
    query = "SELECT * FROM usuarios WHERE id = %s"

    myCursor.execute(query, (user_id,))

    user_data = myCursor.fetchone()
    myCursor.close()
    print (user_data)
    return user_data

def login():
    return render_template('login.php')

@app.route('/recibir_datos', methods=["POST"]) 
def Recibir_datos():
    if request.method == "POST":
        name = request.form['nombre']
        email = request.form['email']
        region = request.form['region']
        contacto = request.form['contacto']
        intereses = request.form['intereses']
        mensaje = request.form['mensaje']
        query = f"INSERT INTO contacto (nombre, email, region, contacto, intereses, mensaje) VALUES('{name}','{email}','{region}','{contacto}','{intereses}','{mensaje}')"
        myCursor.execute(query)
        mydb.commit()
        return redirect(url_for('landing'))
    else:
        return "El formulario de contacto no se envio correctamente"

@app.route('/trip')
def trip():
    return render_template('trip.html')

@app.route('/confirmar')
def confirmar():
    return render_template('confirmar.html')

if __name__=="__main__":
    app.run(debug=True)