from flask import Flask, render_template,request,redirect, url_for, jsonify
from flask_graphql import GraphQLView
import graphene
import mysql.connector

mydb = mysql.connector.connect(
    host = "localhost",
    user = "root",
    port = 3306,
    password= "",
    database ="DB proyecto final",
)

myCursor = mydb.cursor()

app = Flask(__name__)

app.static_folder = 'Static'

"""-----------Graph QL------------"""

#tipos de datos GraphQL
class Usuario(graphene.ObjectType):
    id = graphene.ID()
    nombre = graphene.String()
    email = graphene.String()

#consulta 
class Query(graphene.ObjectType):
    usuario = graphene.Field(Usuario, id=graphene.Int())

    def resolve_usuario(self, info, id):
        query = "SELECT id, nombre, email FROM usuarios WHERE id = %s"
        with mydb.cursor() as cursor:
            cursor.execute(query, (id,))
            user_data = cursor.fetchone()
            if user_data:
                return Usuario(id=user_data[0], nombre=user_data[1], email=user_data[2])
            else:
                return None

    all_users = graphene.List(Usuario)
    
    def resolve_all_users(self, info):
        query = "SELECT id, nombre, email FROM usuarios"
        with mydb.cursor() as cursor:
            cursor.execute(query)
            users_data = cursor.fetchall()
            return [Usuario(id=user[0], nombre=user[1], email=user[2]) for user in users_data]

schema = graphene.Schema(query=Query)

#agregamos la ruta (ej: localhost:5000/graphql)
app.add_url_rule('/graphql', view_func=GraphQLView.as_view('graphql', schema=schema, graphiql=True))

"""-----------Graph QL Finished------------"""

@app.route('/')
def index():
    return redirect(url_for('landing'))

@app.route('/landing')
def landing():
    print("acceder a landing")
    user_id = request.args.get('user_id', '')
    user_data = fetch_user_data(user_id)
    return render_template('landing.html', user_data=user_data)

def fetch_user_data(user_id):
    myCursor = mydb.cursor()
    query = "SELECT * FROM usuarios WHERE id = %s"

    myCursor.execute(query, (user_id,))

    user_data = myCursor.fetchone()
    myCursor.close()
    print ("id", user_id,"\ndatoss",user_data)
    return user_data

"""def extraer_temp_data():
    myCursor = mydb.cursor()
    query = "SELECT * FROM temp WHERE id = 1"

    myCursor.execute(query, )

    temp_data = myCursor.fetchone()
    myCursor.close()
    print ("datoss",temp_data)
    return temp_data"""

def login():
    return render_template('login.php')

@app.route('/recibir_datos', methods=["POST"]) 
def Recibir_datos():
    if request.method == "POST":
        name = request.form['nombre']
        email = request.form['email']
        region = request.form['region']
        contacto = request.form['contacto']
        intereses = request.form['intereses']
        mensaje = request.form['mensaje']
        query = f"INSERT INTO contacto (nombre, email, region, contacto, intereses, mensaje) VALUES('{name}','{email}','{region}','{contacto}','{intereses}','{mensaje}')"
        myCursor.execute(query)
        mydb.commit()
        return redirect(url_for('landing'))
    else:
        return "El formulario de contacto no se envio correctamente"

@app.route('/trip')
def trip():
    print("acceder a trip")
    user_id = request.args.get('user_id', '')
    user_data = fetch_user_data(user_id)
    return render_template('trip.html', user_data=user_data)

@app.route('/confirmar', methods=['GET', 'POST'])
def confirmar():
    if request.method == 'POST':
        print("Acceder a confirmar")
        data = request.json
        print(data)

        query = """
        REPLACE INTO temp (id, fecha_ini, fecha_fin, destino, transporte, comida, hotel, foto)
        VALUES (1, %s, %s, %s, %s, %s, %s, %s)
        """

        values = (
            data['startDate'],
            data['endDate'],
            data['destination'],
            data['transport'],
            data['food'],
            data['hotel'],
            data['photo']
        )
        global trip_data
        trip_data = data

        myCursor.execute(query, values)
        mydb.commit()
        #print(tripDetails)
        return jsonify({"message": "Datos recibidos"})

    else:
        user_id = request.args.get('user_id', '')
        user_data = fetch_user_data(user_id)
        return render_template('confirmar.html', user_data=user_data, trip_data=trip_data)

@app.route('/obtener_precio', methods=['POST'])
def obtener_precio():
    data = request.json
    destination = data['destination']
    transport = data['transport']
    hotel = data['hotel']
    photo = data['photo']
    
    query = f"SELECT {destination},{transport},{hotel},{photo} FROM precios LIMIT 1"
    myCursor.execute(query)
    precio = myCursor.fetchone()
    
    if precio:
        print("precioooooss", precio)
        #return jsonify({"precio_destino": precio[0]},{"precio_transporte": precio[1]},{"precio_hotel": precio[2]},{"precio_foto": precio[3]})
        return jsonify(precio[0], precio[1],precio[2],precio[3])
        return jsonify(precio)
    else:
        print("precio no exist")
        return jsonify({"error": "Precio no encontrado"}), 404

if __name__=="__main__":
    #para usar https
    app.run(debug=True, host='127.0.0.1', port=5000, ssl_context=('ssl/server.cert', 'ssl/server.key'))
