from flask import Flask, render_template,request,redirect, url_for, jsonify
from flask_graphql import GraphQLView
import graphene
import datetime
import mysql.connector

mydb = mysql.connector.connect(
    host = "localhost",
    user = "root",
    port = 3306,
    password= "",
    database ="DB proyecto final",
)

myCursor = mydb.cursor()

app = Flask(__name__)

app.static_folder = 'Static'

def check_and_reconnect():
    if not mydb.is_connected():
        mydb.reconnect()
        global myCursor
        myCursor = mydb.cursor()
"""-----------Graph QL------------"""
#tipos de datos GraphQL
class Usuario(graphene.ObjectType):
    id = graphene.ID()
    nombre = graphene.String()
    email = graphene.String()

class Viaje(graphene.ObjectType):
    id = graphene.ID()
    nombre = graphene.String()
    descripcion = graphene.String()

#consulta 
class Query(graphene.ObjectType):
    usuario = graphene.Field(Usuario, id=graphene.Int())

    def resolve_usuario(self, info, id):
        query = "SELECT id, nombre, email FROM usuarios WHERE id = %s"
        with mydb.cursor() as cursor:
            cursor.execute(query, (id,))
            user_data = cursor.fetchone()
            if user_data:
                return Usuario(id=user_data[0], nombre=user_data[1], email=user_data[2])
            else:
                return None

    all_users = graphene.List(Usuario)
    
    def resolve_all_users(self, info):
        query = "SELECT id, nombre, email FROM usuarios"
        with mydb.cursor() as cursor:
            cursor.execute(query)
            users_data = cursor.fetchall()
            return [Usuario(id=user[0], nombre=user[1], email=user[2]) for user in users_data]
      
    usuarios_por_email = graphene.Field(Usuario, email=graphene.String())
        
    def resolve_usuarios_por_email(self, info, email):
        query = "SELECT id, nombre, descripcion FROM viajes WHERE id = %s"
        with mydb.cursor() as cursor:
            cursor.execute(query, (email,))
            user_data = cursor.fetchone()
            if user_data:
                return Usuario(id=user_data[0], nombre=user_data[1], email=user_data[2])
            else:
                return None

    todos_los_viajes = graphene.Field(Viaje, id=graphene.Int())

    def resolve_viaje(self, info, id):
        query = "SELECT id, destino, trasnporte FROM viajes WHERE id = %s"
        with mydb.cursor() as cursor:
            cursor.execute(query, (id,))
            viaje_data = cursor.fetchone()
            if viaje_data:
                return Viaje(id=viaje_data[0], destino=viaje_data[3], transporte=viaje_data[4])
            else:
                return None
            
    def resolve_todos_viajes(self, info):
        query = "SELECT id, destino, transporte FROM viajes"
        with mydb.cursor() as cursor:
            cursor.execute(query)
            viajes_data = cursor.fetchall()
            return [Viaje(id=viaje[0], destino=viaje[3], transporte=viaje[4]) for viaje in viajes_data]

class CreateUser(graphene.Mutation):
    class Arguments:
        username = graphene.String(required=True)
        password = graphene.String(required=True)
        nombre = graphene.String(required=True)
        apellido = graphene.String(required=True)
        dni = graphene.String(required=True)
        telefono = graphene.String(required=True)
        fecha_nacimiento = graphene.String(required=True)  
        email = graphene.String(required=True)

    usuario = graphene.Field(Usuario)

    def mutate(self, info, username, password, nombre, apellido, dni, telefono, fecha_nacimiento, email):
        fecha_nacimiento = datetime.datetime.strptime(fecha_nacimiento, '%Y-%m-%d').date()

        query = """
        INSERT INTO usuarios (username, password, nombre, apellido, dni, telefono, fecha_nacimiento, email)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """
        values = (username, password, nombre, apellido, dni, telefono, fecha_nacimiento, email)

        with mydb.cursor() as cursor:
            cursor.execute(query, values)
            user_id = cursor.lastrowid
            mydb.commit()

            return CreateUser(usuario=Usuario(id=user_id, nombre=nombre, email=email))
        
class Mutation(graphene.ObjectType):
    crear_usuario = CreateUser.Field()

schema = graphene.Schema(query=Query, mutation=Mutation)
app.add_url_rule('/graphql', view_func=GraphQLView.as_view('graphql', schema=schema, graphiql=True))

"""-----------Graph QL Finished------------"""

@app.route('/')
def index():
    return redirect(url_for('landing'))

@app.route('/administrador')
def admin():
    user_id = request.args.get('user_id', '')
    user_data = fetch_user_data(user_id)
    return render_template('administrador.html', user_data=user_data)

@app.route('/landing')
def landing():
    print("acceder a landing")
    user_id = request.args.get('user_id', '')
    user_data = fetch_user_data(user_id)
    return render_template('landing.html', user_data=user_data)

def fetch_user_data(user_id):
    myCursor = mydb.cursor()
    query = "SELECT * FROM usuarios WHERE id = %s"

    myCursor.execute(query, (user_id,))

    user_data = myCursor.fetchone()
    myCursor.close()
    print ("id", user_id,"\ndatoss",user_data)
    return user_data

def login():
    return render_template('login.php')

@app.route('/recibir_datos', methods=["POST"]) 
def Recibir_datos():
    if request.method == "POST":
        name = request.form['nombre']
        email = request.form['email']
        region = request.form['region']
        contacto = request.form['contacto']
        intereses = request.form['intereses']
        mensaje = request.form['mensaje']
        query = f"INSERT INTO contacto (nombre, email, region, contacto, intereses, mensaje) VALUES('{name}','{email}','{region}','{contacto}','{intereses}','{mensaje}')"
        myCursor.execute(query)
        mydb.commit()
        return redirect(url_for('landing'))
    else:
        return "El formulario de contacto no se envio correctamente"

@app.route('/trip')
def trip():
    print("acceder a trip")
    user_id = request.args.get('user_id', '')
    user_data = fetch_user_data(user_id)
    return render_template('trip.html', user_data=user_data)

@app.route('/confirmar', methods=['GET', 'POST'])
def confirmar():
    if request.method == 'POST':
        print("Acceder a confirmar")
        data = request.json
        print(data)

        query = """
        REPLACE INTO pedidos (id, fecha_ini, fecha_fin, destino, transporte, comida, hotel, foto)
        VALUES (1, %s, %s, %s, %s, %s, %s, %s)
        """
        values = (
            data['startDate'],
            data['endDate'],
            data['destination'],
            data['transport'],
            data['food'],
            data['hotel'],
            data['photo']
        )
        global trip_data
        trip_data = data

        myCursor.execute(query, values)
        mydb.commit()
        return jsonify({"message": "Datos recibidos"})

    else:
        user_id = request.args.get('user_id', '')
        user_data = fetch_user_data(user_id)
        return render_template('confirmar.html', user_data=user_data, trip_data=trip_data)

@app.route('/obtener_precio', methods=['POST'])
def obtener_precio():
    data = request.json
    destination = data['destination']
    transport = data['transport']
    hotel = data['hotel']
    photo = data['photo']
    
    query = f"SELECT {destination},{transport},{hotel},{photo} FROM precios LIMIT 1"
    myCursor.execute(query)
    precio = myCursor.fetchone()
    
    if precio:
        print("precioooooss", precio)
        return jsonify(precio)
    else:
        print("precio no exist")
        return jsonify({"error": "Precio no encontrado"}), 404

@app.route('/guardar_pedido', methods=['POST'])
def guardar_pedido():
    data = request.json
    start_date = data.get('startDate')
    end_date = data.get('endDate')
    destination = data.get('destination')
    hotel = data.get('hotel')
    transport = data.get('transport')
    food = data.get('food')
    photo = data.get('photo')
    price = data.get('price')
    user_id = data.get('user_id')

    if not all([start_date, end_date, destination, hotel, transport, food, photo, user_id]):
        return jsonify({"success": False, "message": "Missing required fields"}), 400
    try:
        query = ("INSERT INTO pedidos (user_id, fecha_ini, fecha_fin, destino, hotel, transporte, comida, foto) "
                 "VALUES (%s, %s, %s, %s, %s, %s, %s, %s)")
        values = (user_id, start_date, end_date, destination, hotel, transport, food, photo)
        myCursor.execute(query, values)
        mydb.commit()

        return jsonify({"success": True, "message": "Order saved successfully"}), 200

    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return jsonify({"success": False, "message": "Database error"}), 500

@app.route('/obtener_pedidos', methods=['GET'])
def obtener_pedidos():
    user_id = request.args.get('user_id')  # Opcional: Filtrar por ID de usuario
    check_and_reconnect()
    try:
        if user_id:
            query = "SELECT * FROM pedidos WHERE user_id = %s" #no se usa tdv
            myCursor.execute(query, (user_id,))
        else:
            query = "SELECT * FROM pedidos WHERE user_id IS NOT NULL"
            myCursor.execute(query)

        pedidos = myCursor.fetchall()
        pedidos_list = []
        for pedido in pedidos:
            pedidos_list.append({
                'id': pedido[0],
                'user_id': pedido[2],
                'start_date': pedido[3],
                'end_date': pedido[4],
                'destination': pedido[5],
                'hotel': pedido[8],
                'transport': pedido[6],
                'food': pedido[7],
                'photo': pedido[9],
            })
        return jsonify({"success": True, "data": pedidos_list}), 200
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return jsonify({"success": False, "message": "Database error"}), 500

if __name__=="__main__":
    #para usar https
    app.run(debug=True, host='127.0.0.1', port=5000, ssl_context=('ssl/server.cert', 'ssl/server.key'))
